<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 */
abstract class BaseController extends Controller
{
    /**
     * Instance of the main Request object.
     *
     * @var CLIRequest|IncomingRequest
     */
    protected $request;

    /**
     * An array of helpers to be loaded automatically upon
     * class instantiation. These helpers will be available
     * to all other controllers that extend BaseController.
     *
     * @var array
     */
    protected $helpers = [];

    /**
     * Be sure to declare properties for any property fetch you initialized.
     * The creation of dynamic property is deprecated in PHP 8.2.
     */
    // protected $session;

    /**
     * @return void
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        // Preload any models, libraries, etc, here.

        // E.g.: $this->session = \Config\Services::session();
    }

    public function upload_file($upload_folder, $file_name, $allowed_types = null, $full_url = true)
    {

        $file = $this->request->getFile($file_name);

        if ($file === null) {
            throw new \RuntimeException('No file uploaded with name: ' . $file_name);
        }


        if ($file->isValid() && !$file->hasMoved()) {
            $fileExt = $file->getClientExtension();

            // Check if file type is allowed
            if (!is_null($allowed_types) && !in_array($fileExt, $allowed_types)) {
                log_message('error', 'Disallowed file type: ' . $fileExt);
                return false;
            }


            if ($fileExt == 'pdf') {
                $return['file_type'] = 'pdf';
            } elseif (in_array($fileExt, ['mp3', 'aac'])) {
                $return['file_type'] = 'audio';
            } else {
                $return['file_type'] = 'image';
            }

            $uploadPath = WRITEPATH.'uploads/' . $upload_folder . '/' . date("Ym");
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }

            // Set file upload options
            $file->move($uploadPath, $file->getRandomName());

            if ($full_url) {
                $return['file'] = 'uploads/' . $upload_folder . '/' . date("Ym") . '/' . $file->getName();
            } else {
                $return['file'] = date("Ym") . '/' . $file->getName();
            }

            return $return;
        } else {
            // Handle error
            log_message('error', $file->getErrorString().'('.$file->getError().')');
            return false;
        }
    }
    
    //create slug
    public	function create_slug($string){
       $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '_', $string)));
       return $slug;
    }

}
