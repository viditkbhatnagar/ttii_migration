<?php

namespace App\Controllers;

use App\Models\Users_model;
use App\Entities\User;

class Home extends BaseController
{
    private $users_model;
    private $user;

    public function __construct()
    {
        $this->users_model = new Users_model();
        $this->user = new User();

    }
    
    public function leads(){
        
        return view('leads');
    }

    public function index(): string
    {

        $this->users_model = new Users_model();
        $user = new User([
            'name' => 'John C',
            'password' => '7878787878',
            'email' => 'john@example.com4'
        ]);

        $this->user->fill([
            'name' => 'John C',
            'password' => '7878787878',
            'email' => 'john@example.com4'
        ]);

        if (!$this->users_model->save($user)) {
            $errors = $this->users_model->errors();
            var_dump($errors);
        }




        $users = $this->users_model->get(['id' => 1], ['email', 'name']);

        foreach ($users as $user) {
            echo "<hr>";
            echo "Name: " . esc($user->name) . "<br>";
            echo "Email: " . esc($user->email) . "<br>";
            echo "<hr>";
        }




        return view('index');
    }


    private function create_seeder(){
        // use Config\Database;
        // Get the database seeder
        // $seeder = Database::seeder();

        // Run the specific seeder
        // $seeder->call('User_seeder');
    }
}
