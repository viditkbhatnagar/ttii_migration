<?php namespace App\Controllers;

class FileController extends BaseController
{
    public function serveFile()
    {
        // Add any authentication or authorization checks here
        if (!is_logged_in()) {
            readfile(base_url('assets/public/permission_denied.png'));
        }
        $filename = decode_file($this->request->getGet('item'));
        $filePath = WRITEPATH . $filename;

        if (!is_file($filePath)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('File not found');
        }else{
            // Set appropriate headers
            header('Content-Type: ' . mime_content_type($filePath));
            header('Content-Length: ' . filesize($filePath));

            readfile($filePath);
        }
        exit;
    }
}
