<?php

namespace App\Controllers;

use App\Models\Users_model;
use App\Models\User_role_model;
use App\Entities\User;

class Login extends PublicBaseController
{
    private $users_model;
    private $user_role_model;
    private $user;

    public function __construct()
    {
        parent::__construct();

        $this->users_model = new Users_model();
        $this->user_role_model = new User_role_model();
        $this->user = new User();
    }

    public function index()
    {
        if ($this->request->getMethod() === 'post') {
            $this->_action_login();
        }
        if (is_logged_in()) {
            return redirect()->to(base_url('app/dashboard/index'));
        }

        return view('Frontend/Login/index', $this->data);
    }

    private function _action_login()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $login = $this->users_model->login($email, $password);

        if ($login['status'] == 1){
            $user = $login['user'];
            $user_role = $this->user_role_model->get(['id' => $user->role_id])->getRow()->title ?? '';
            //set session
            $session = session();
            $session->set([
                'user_id' => $user->id,
                'role_id' => $user->role_id,
                'role_title' => $user_role,
                'user_name' => $user->name,
                'user_email' => $user->email,
                'is_logged_in' => true,
                'logged_in_at' => time(),
                'site_title' => get_site_title(),
                'site_logo' => get_site_logo(),
            ]);
            $session->setFlashdata('message_success', "Welcome back! <b>{$user->name}</b>");
        }else{
            $this->data['error'] = $login['message'];
        }
    }

    // Logout the session
    public function logout()
    {
        session()->remove([
            'user_id',
            'role_id',
            'role_title',
            'name',
            'email',
            'is_logged_in',
            'logged_in_at',
            'site_title',
            'site_logo',
        ]);
        return redirect()->to(base_url('login/index'));
    }
}
