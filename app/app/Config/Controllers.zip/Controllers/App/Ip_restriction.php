<?php
namespace App\Controllers\App;
use App\Models\Users_model;
use App\Models\Teams_model;
use App\Models\Team_members_model;
use App\Models\Ip_restriction_model;
class Ip_restriction extends AppBaseController
{
    private $users_model;
    private $ip_restriction_model;
    private $Team_members_model;
    private $teams_model;
    public function __construct()
    {
        parent::__construct();
        $this->users_model = new Users_model();
        $this->ip_restriction_model = new Ip_restriction_model();
        $this->team_members_model = new Team_members_model();
        $this->teams_model = new Teams_model();
        
    }

    public function index(){
        $this->data['teams_list'] = $this->teams_model->get_team_with_member_count();
        $this->data['teams'] = array_column($this->data['teams_list'], 'title', 'id');
        $this->data['user_name'] = $this->users_model->get_array_column([], 'id', 'name');
        $this->data['list_items'] = $this->ip_restriction_model->get()->getResultArray();
        $this->data['page_title'] = 'Ip Restriction';
        $this->data['page_name'] = 'Ip_restriction/index';
        return view('App/index', $this->data);
    }
    
    public function ajax_add(){
        $this->data['teams'] = $this->teams_model->get()->getResultArray();
        echo view('App/Ip_restriction/ajax_add', $this->data);
    }
    
    public function add(){
        if ($this->request->getMethod() === 'post'){
            $data = [
                'user_id'    => $this->request->getPost('user_id'),
                'team_id'   => $this->request->getPost('team_id'),
                'ip_from'   => $this->request->getPost('ip_from'),
                'ip_to'     => $this->request->getPost('ip_to'),
                'comments'     => $this->request->getPost('comments'),
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => get_user_id(),
                'updated_by' => get_user_id(),
                'updated_at' => date('Y-m-d H:i:s'),
            ];
            
            $admin_id = $this->ip_restriction_model->add($data);
            if ($admin_id){
                session()->setFlashdata('message_success', "IP Restricted Successfully!");
            }else{
                session()->setFlashdata('message_danger', "Something went wrong! Try Again");
            }
        }
        return redirect()->to(base_url('app/ip_restriction/index'));
    }
    
    public function ajax_edit($id){
        $this->data['teams'] = $this->teams_model->get()->getResultArray();
        $this->data['team_members'] = $this->team_members_model->get_join(
            [
                ['users', 'users.id = team_members.member_id'],
            ]
        )->getResultArray();
        $this->data['edit_data'] = $this->ip_restriction_model->get(['id' => $id])->getRowArray();
        echo view('App/Ip_restriction/ajax_edit', $this->data);
    }

    public function edit($id){
        if ($this->request->getMethod() === 'post'){
            $data = [
                'user_id'    => $this->request->getPost('user_id'),
                'team_id'   => $this->request->getPost('team_id'),
                'ip_from'   => $this->request->getPost('ip_from'),
                'ip_to'     => $this->request->getPost('ip_to'),
                'comments'     => $this->request->getPost('comments'),
                'updated_by' => get_user_id(),
                'updated_at' => date('Y-m-d H:i:s'),
            ];
            $response = $this->ip_restriction_model->edit($data, ['id' => $id]);
            if ($response){
                session()->setFlashdata('message_success', "IP Restriction Updated Successfully!");
            }else{
                session()->setFlashdata('message_danger', "Something went wrong! Try Again");
            }
        }
        return redirect()->to(base_url('app/ip_restriction/index'));
    }

    public function ajax_view($id){
        $this->data['view_data'] = $this->ip_restriction_model->get(['id' => $id])->getRowArray();
        echo view('App/Ip_restriction/ajax_view', $this->data);
    }
    
    public function delete($id){
        if ($id > 0){
            if ($this->ip_restriction_model->remove(['id' => $id])){
                session()->setFlashdata('message_success', "IP Restriction Deleted Successfully!");
            }else{
                session()->setFlashdata('message_danger', "Something went wrong! Try Again");
            }
        }else{
            session()->setFlashdata('message_danger', "Something went wrong! Try Again");
        }
        return redirect()->to(base_url('app/ip_restriction/index'));
    }
    
}
