<?php
namespace App\Controllers\App;
use App\Controllers\App\AppBaseController;
class Exports extends AppBaseController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(){
        $this->data['page_title'] = 'Exports';
        $this->data['page_name'] = 'Exports/index';
        return view('App/index', $this->data);
    }
}
