<?php
namespace App\Controllers\App;
use App\Models\Users_model;
use App\Models\Teams_model;
use App\Models\Team_members_model;
use App\Models\Designation_model;
class Colleagues extends AppBaseController
{
    private $users_model;
    private $teams_model;
    private $team_members_model;
    private $designation_model;
    public function __construct()
    {
        parent::__construct();
        $this->users_model = new Users_model();
        $this->teams_model = new Teams_model();
        $this->team_members_model = new Team_members_model();
        $this->designation_model = new Designation_model();

    }

    public function index($team_id = null){
        $this->data['teams_list'] = $this->teams_model->get_team_with_member_count();
        $this->data['total_members'] = $this->team_members_model->get()->getNumRows();
        $this->data['teams'] = array_column($this->data['teams_list'], 'title', 'id');
        $this->data['designation'] = $this->designation_model->get_array_column([], 'id', 'title');
        $this->data['teams_filter'] = $this->teams_model->get()->getResultArray();
        $this->data['team_members'] = $this->team_members_model->get_array_column([], 'member_id', 'team_id');
        
        $where['users.role_id !='] = 1;
        if(!empty($team_id)){
            $where['team_members.team_id'] = $team_id;
        }
         
        $this->data['list_items'] = $this->team_members_model->get_join(
            [
                ['users', 'users.id = team_members.member_id'],
            ],
            $where, null, ['users.name' => 'asc']
        )->getResultArray();
        
        $this->data['team_id'] = $team_id;
        $this->data['page_title'] = 'Colleagues';
        $this->data['page_name'] = 'Colleagues/index';
        return view('App/index', $this->data);
    }

    public function ajax_view($id){
        $this->data['view_data'] = $this->users_model->get(['id' => $id])->getRowArray();
        $this->data['teams'] = $this->teams_model->get_array_column([], 'id', 'title');
        $this->data['team_members'] = $this->team_members_model->get_array_column([], 'member_id', 'team_id');
        echo view('App/Colleagues/ajax_view', $this->data);
    }
}
