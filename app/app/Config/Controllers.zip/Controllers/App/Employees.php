<?php
namespace App\Controllers\App;
use App\Models\Users_model;
use App\Models\Team_members_model;
use App\Models\Teams_model;
use App\Models\Designation_model;
class Employees extends AppBaseController
{
    private $users_model;
    private $team_members_model;
    private $teams_model;
    private $designation_model;
    public function __construct()
    {
        parent::__construct();
        $this->users_model = new Users_model();
        $this->team_members_model = new Team_members_model();
        $this->teams_model = new Teams_model();
        $this->designation_model = new Designation_model();

    }

    public function index($team_id = null){
        $this->data['designation'] = $this->designation_model->get_array_column([], 'id', 'title');
        
        $this->data['teams_list'] = $this->teams_model->get_team_with_member_count();
        $this->data['total_members'] = $this->team_members_model->get()->getNumRows();
        $this->data['teams'] = array_column($this->data['teams_list'], 'title', 'id');
        $this->data['team_members'] = $this->team_members_model->get_array_column([], 'member_id', 'team_id');
        
        $where['users.role_id'] = 2;
        if(!empty($team_id)){
            $where['team_members.team_id'] = $team_id;
        }
         
        $this->data['list_items'] = $this->team_members_model->get_join(
            [
                ['users', 'users.id = team_members.member_id'],
            ],
            $where, null, ['users.name' => 'asc']
        )->getResultArray();
        
        $this->data['team_id'] = $team_id;
        $this->data['page_title'] = 'Employees';
        $this->data['page_name'] = 'Employees/index';
        return view('App/index', $this->data);
    }

    public function ajax_add(){
        $this->data['teams'] = $this->teams_model->get()->getResultArray();
        $this->data['designations'] = $this->designation_model->get()->getResultArray();
        echo view('App/Employees/ajax_add', $this->data);
    }

    public function add(){
        if ($this->request->getMethod() === 'post'){
            
            $phone = $this->request->getPost('phone');
            $email = $this->request->getPost('email');
            $employee_code = $this->request->getPost('employee_code');
            $check_phone_duplication = $this->users_model->get(['phone' => $phone])->getNumRows();
            $check_email_duplication = $this->users_model->get(['email' => $email])->getNumRows();
            $check_employee_duplication = $this->users_model->get(['employee_code' => $employee_code])->getNumRows();
            
            if($check_phone_duplication > 0){
                session()->setFlashdata('message_danger', "Phone Number Already Exists");
            }elseif($check_email_duplication > 0){
                session()->setFlashdata('message_danger', "Email Already Exists");
            }elseif($check_employee_duplication > 0){
                session()->setFlashdata('message_danger', "Employee code Already Exists");
            }else{
                
                $data = [
                    'name' => $this->request->getPost('name'),
                    'email' => $email,
                    'employee_code' => $this->request->getPost('employee_code'),
                    'phone' => $phone,
                    'role_id' => 2,
                    'dob' => date('Y-m-d', strtotime($this->request->getPost('dob'))),
                    'jod' => date('Y-m-d', strtotime($this->request->getPost('jod'))),
                    'password'  => $this->users_model->password_hash($this->request->getPost('password')),
                    'user_designation_id' => $this->request->getPost('user_designation_id'),
                    'created_by' => get_user_id(),
                    'created_at' => date('Y-m-d H:i:s'),
                ];
                $profile_picture = $this->upload_file('users/employee','profile_picture');
                if($profile_picture && valid_file($profile_picture['file'])){
    				$data['profile_picture'] = $profile_picture['file'];
    			}
                
                $employee_id = $this->users_model->add($data);
                if($employee_id){
                    $team_id = $this->request->getPost('team_id');
                    if($team_id >0){
                        $team_members = [
                            'team_id' => $team_id,
                            'member_id' => $employee_id,
                            'created_by' => get_user_id(),
                            'created_at' => date('Y-m-d H:i:s')
                        ];  
                        $this->team_members_model->add($team_members);
                    }
                }
            
                if ($employee_id){
                    session()->setFlashdata('message_success', "Employees Added Successfully!");
                }else{
                    session()->setFlashdata('message_danger', "Something went wrong! Try Again");
                }
            }
        }
        return redirect()->to(base_url('app/employees/index'));
    }

    public function ajax_edit($id){
        
        $this->data['teams'] = $this->teams_model->get()->getResultArray();
        $this->data['designations'] = $this->designation_model->get()->getResultArray();
        $this->data['edit_data'] = $this->users_model->get(['id' => $id])->getRowArray();
        
        $team_member = $this->team_members_model->get(['member_id' => $id]);
        
        $this->data['edit_data']['team_id'] = $team_member->getNumRows() > 0 ? $team_member->getRow()->team_id : 0;
        
       
        echo view('App/Employees/ajax_edit', $this->data);
    }

    public function edit($id){
        if ($this->request->getMethod() === 'post'){
            
            $phone = $this->request->getPost('phone');
            $email = $this->request->getPost('email');
            $employee_code = $this->request->getPost('employee_code');
            $check_phone_duplication = $this->users_model->get(['phone' => $phone, 'id !=' => $id])->getNumRows();
            $check_email_duplication = $this->users_model->get(['email' => $email, 'id !=' => $id])->getNumRows();
            $check_employee_duplication = $this->users_model->get(['employee_code' => $employee_code, 'id !=' => $id])->getNumRows();
            if($check_phone_duplication == 0 && $check_email_duplication == 0 && $check_employee_duplication == 0){
                $data = [
                    'name' => $this->request->getPost('name'),
                    'email' => $this->request->getPost('email'),
                    'phone' => $this->request->getPost('phone'),
                    'employee_code' => $this->request->getPost('employee_code'),
                    'dob' => date('Y-m-d', strtotime($this->request->getPost('dob'))),
                    'jod' => date('Y-m-d', strtotime($this->request->getPost('jod'))),
                    'user_designation_id' => $this->request->getPost('user_designation_id'),
                    'updated_by' => get_user_id(),
                    'updated_at' => date('Y-m-d H:i:s')
                ];
                
                $profile_picture = $this->upload_file('users/employee','profile_picture');
                if($profile_picture && valid_file($profile_picture['file'])){
    				$data['profile_picture'] = $profile_picture['file'];
    			}
                $response = $this->users_model->edit($data, ['id' => $id]);
                
                if($response){
                    $team_id = $this->request->getPost('team_id');
                    $_is_team_exists = $this->team_members_model->get(['member_id' => $id])->getNumRows() > 0; // Checking data exist
                    if($team_id > 0){
                        $team_members = [
                            'member_id' => $id,
                            'team_id' => $team_id,
                        ];  
                        if($_is_team_exists > 0){
                            // is data exists
                            $team_members['updated_by'] = get_user_id();
                            $team_members['updated_at'] = date('Y-m-d H:i:s');
                            
                            $this->team_members_model->edit($team_members, ['member_id' => $id]);
                        }else{
                            // is no data exists
                            $team_members['created_by'] = get_user_id();
                            $team_members['created_at'] = date('Y-m-d H:i:s');
                            $this->team_members_model->add($team_members);
                        }
                    }else{
                        //is team_id = 0 delete the data
                        $team_members = [
                            'team_id' => $team_id,
                        ];
                        $this->team_members_model->edit($team_members, ['member_id' => $id]);
                        $this->team_members_model->remove(['member_id' => $id]);
                    }
                }
                
                if ($response){
                    session()->setFlashdata('message_success', "Employees Updated Successfully!");
                }else{
                    session()->setFlashdata('message_danger', "Something went wrong! Try Again");
                }
            }else{
                session()->setFlashdata('message_danger', "User Already Exists");
            }
        }
        return redirect()->to(base_url('app/employees/index'));
    }
    
    public function ajax_reset_password($id){
        
        $this->data['employee_id'] = $id;
        
        echo view('App/Employees/ajax_reset_password', $this->data);
    }
    
    public function reset_password($id){
        if ($this->request->getMethod() === 'post'){
            $data = [
                'password'  => $this->users_model->password_hash($this->request->getPost('password')),
                'updated_by' => get_user_id(),
                'updated_at' => date('Y-m-d H:i:s'),
            ];
            
            $response = $this->users_model->edit($data, ['id' => $id]);
            if ($response){
                session()->setFlashdata('message_success', "Password Reset Successfully!");
            }else{
                session()->setFlashdata('message_danger', "Something went wrong! Try Again");
            }
        }
        return redirect()->to(base_url('app/employees/index/'));
    }

    public function ajax_view($id){
        $this->data['designation'] = $this->designation_model->get_array_column([], 'id', 'title');
        $this->data['view_data'] = $this->users_model->get(['id' => $id])->getRowArray();
        $this->data['teams'] = $this->teams_model->get_array_column([], 'id', 'title');
        $this->data['team_members'] = $this->team_members_model->get_array_column([], 'member_id', 'team_id');
        echo view('App/Employees/ajax_view', $this->data);
    }

    public function delete($id){
        if ($id > 0){
            if ($this->users_model->remove(['id' => $id])){
                session()->setFlashdata('message_success', "Employees Deleted Successfully!");
            }else{
                session()->setFlashdata('message_danger', "Something went wrong! Try Again");
            }
        }else{
            session()->setFlashdata('message_danger', "Something went wrong! Try Again");
        }
        return redirect()->to(base_url('app/employees/index'));
    }
}
