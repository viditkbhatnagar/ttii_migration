<?php
namespace App\Controllers\App;
use App\Controllers\App\AppBaseController;
use App\Models\User_app_usage_model;
use App\Models\Apps_model;
use App\Models\Mostly_used_model;

class Dashboard extends AppBaseController
{
    private $user_app_usage_model;
    private $apps_model;
    private $mostly_used_model;
    public function __construct()
    {
        parent::__construct();
        $this->user_app_usage_model = new User_app_usage_model();
        $this->apps_model = new Apps_model();
        $this->mostly_used_model = new Mostly_used_model();
    }

    public function index(){
        
        $this->data['arrival_time'] = $this->user_app_usage_model->getAvg_arrival_time();
        $this->data['last_time'] = $this->user_app_usage_model->getAvg_last_time();
        $this->data['total_desktime'] = $this->user_app_usage_model->getAvg_total_desktime();
        $this->data['total_time_at_work'] = $this->user_app_usage_model->getAvg_total_time_at_work();


        
        $this->data['top_used_apps'] = $this->user_app_usage_model->get_top_five_used_apps();
        $this->data['last_used_apps'] = $this->user_app_usage_model->get_last_five_used_apps();
        
        
        
        
        
        $this->data['page_title'] = 'Dashboard';
        $this->data['page_name'] = 'Dashboard/index';
        return view('App/index', $this->data);
    }
    
     public function store_app()
     {
           $get_app_by_usage = $this->user_app_usage_model->get_app_by_usage();
           
        //       echo "<pre>";
        //   print_r($get_app_by_usage); exit();
           
           foreach($get_app_by_usage as $app)
           {
               $data = [
                'title' => $app,
             
                'created_by' => get_user_id(),
                'created_at' => date('Y-m-d H:i:s'),
            
                ];
                
                $insert = $this->mostly_used_model->add($data);

          }
           
           
           
       
     }
     
    
    
}
