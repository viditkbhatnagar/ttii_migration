<?php

if (!function_exists('get_vimeo_file_url')) {
    function get_vimeo_file_url($vimeo_url) {
    
        $accessToken = '617b535bb5df0019133cae322ac03f27';
    
        if (preg_match('/vimeo\.com\/(\d+)/', $vimeo_url, $matches)) {
            $vimeoVideoId = $matches[1];
        } else {
            return [
                'status' => 'false',
                'message' => 'Invalid Vimeo URL',
                'video_link' => null
            ];
        }
    
        $vimeoApiUrl = "https://api.vimeo.com/videos/$vimeoVideoId";
    
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $vimeoApiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Authorization: Bearer $accessToken"
        ));
        $response = curl_exec($ch);
        curl_close($ch);
    
        $videoInfo = json_decode($response, true);
        
        $files      = [];
        $downloads  = [];
    
        if (isset($videoInfo['files'])) 
        {
            $files      =   $videoInfo['files'];
            $downloads  =   $videoInfo['download'];
            
            
            return [
                'status' => 'false',
                'message' => 'Detailed fetched for this video',
                'files' => $files,
                'downloads' => $downloads
            ];
        } 
        else 
        {
            return [
                'status' => 'false',
                'message' => 'Error fetching video details or invalid video ID',
                'files' => $files,
                'downloads' => $downloads
            ];
        }
    }
}