<?php
if (!function_exists('encode_file')){
    function encode_file($file_path) {
        return base64_encode($file_path);
    }
}

if (!function_exists('decode_file')){
    function decode_file($file_path) {
        return base64_decode($file_path);
    }
}

if (!function_exists('valid_file')){
    function valid_file($file_path) {
        return is_file(WRITEPATH.$file_path);
    }
}

if (!function_exists('get_file_url')){
    function get_file($file_path) {
        $file_path = encode_file($file_path);
        return "file/?item={$file_path}&expiry=".time();
    }
}